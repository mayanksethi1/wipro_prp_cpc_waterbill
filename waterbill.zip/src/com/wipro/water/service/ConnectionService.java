package com.wipro.water.service;


import com.wipro.water.entity.CommercialConnectionBean;
import com.wipro.water.entity.DomesticConnectionBean;
import com.wipro.water.exception.IncorrectConnectionException;
import com.wipro.water.exception.IncorrectReadingException;

public class ConnectionService {

	public boolean validateData(int currentReading, int previousReading, String type)throws IncorrectReadingException, IncorrectConnectionException
	{
		//write code here
		if(currentReading<previousReading || currentReading<=0||previousReading<=0){
			throw new IncorrectReadingException();
		}
		else if(!(type.equals("Domestic")||type.equals("Commercial"))){
			throw new IncorrectConnectionException();
		}
		return true;
	}

	public float generateBill(int currentReading, int previousReading,	String type) 
	{
		float bill=-0.0f;
		try{
			if(validateData(currentReading,previousReading,type)== true){
				if(type.equals("Domestic")){
					float slabs[] = {3.9f,5.2f,8.3f};
					DomesticConnectionBean dc = new DomesticConnectionBean(currentReading, previousReading, slabs);
					bill = dc.evaluateBill();
				}
				else if(type.equals("Commercial")){
					float slabs[] = {5.1f,6.8f,9.3f};
					CommercialConnectionBean cc = new CommercialConnectionBean(currentReading, previousReading, slabs);
					bill = cc.evaluateBill();
			}
		}
			}
		catch(IncorrectReadingException ie){
			return -1;
		}
		catch(IncorrectConnectionException ic){
			return -2;
			}
		
		return bill;
	}
	
	public String computeFinalBill(int currentReading, int previousReading, String type)
	{
			String result="";
			//write code here
			float a = 0;
			a = generateBill(currentReading, previousReading, type);
			if(a==-1){
				return "Enter correct Reading";
			}
			else if(a==-2){
				return "Enter a valid Connection";
			}
			else{
				result = "Total Amount to be paid is : "+a;
			}
			return result;
	}
	
}
