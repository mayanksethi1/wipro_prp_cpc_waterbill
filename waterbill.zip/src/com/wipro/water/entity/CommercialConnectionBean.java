package com.wipro.water.entity;

public class CommercialConnectionBean extends ConnectionBean {

	public CommercialConnectionBean(int currentReading, int previousReading,float slabs[]) {
		super(currentReading, previousReading,slabs);
		//write code here
		this.currentReading= currentReading;
		this.previousReading = previousReading;
		this.slabs = slabs;
	}

	
	public float evaluateBill() {
				float amount=-1;
		        //write code here
				float bill = 0.0f;
				float monthReading = currentReading-previousReading;
				float surchargeDuty = 0.0f;
				float slabs[] = {5.1f,6.8f,9.3f};
				if(monthReading>0&& monthReading<=60){
					bill = bill +monthReading*slabs[0];
				}
				else if(monthReading>=61 && monthReading<=120){
					bill = bill+60*slabs[0]+(monthReading-60)*slabs[1];
				}
				else if(monthReading>120){
					bill = bill+60*slabs[0]+60*slabs[1]+(monthReading-120)*slabs[2];
				}
				if(bill>=9000){
					surchargeDuty = bill*0.08f;
				}
				else if(bill>=5000){
					surchargeDuty = bill*0.06f;
				}
				else if(bill<5000){
					surchargeDuty = bill*0.03f;
				}
				amount = bill+surchargeDuty;
				return amount;
	}

}
 
