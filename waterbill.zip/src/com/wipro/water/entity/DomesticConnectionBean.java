package com.wipro.water.entity;

public class DomesticConnectionBean extends ConnectionBean {

	public DomesticConnectionBean(int currentReading, int previousReading,float slabs[]) {
		super(currentReading, previousReading,slabs);
		//write code here
		this.currentReading= currentReading;
		this.previousReading  = previousReading;
		this.slabs = slabs;
	}

	@Override
	public float evaluateBill() {
		float bill =-1;
		float slabs[] ={3.9f,5.2f,8.3f};
		float monthReading = currentReading-previousReading;
		if(monthReading>0&&monthReading<=60){
			bill = monthReading*slabs[0];
		}
		else if(monthReading>=61&&monthReading<=120){
			bill = 60*slabs[0]+(monthReading-60)*slabs[1];
		}
		else if(monthReading>120){
			bill = +60*slabs[0]+60*slabs[1]+(monthReading-120)*slabs[2];
		}
				
				//write code here
		return bill;
	}
}