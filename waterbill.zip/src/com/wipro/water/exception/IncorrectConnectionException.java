package com.wipro.water.exception;

public class IncorrectConnectionException extends Exception{


	public String toString() {
		//write code here
		return "Enter a valid Connection";
	}
}
