package com.wipro.water.exception;

public class IncorrectReadingException extends Exception {
public String toString()
{
	//write code here
	return "Enter correct Reading";
	}
}
