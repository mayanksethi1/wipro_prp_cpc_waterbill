package com.wipro.water.main;

import com.wipro.water.service.ConnectionService;

public class WaterMain {

	
	public static void main(String a[])
	{
		//write code here
		System.out.println(new ConnectionService().computeFinalBill(230,130,"Commercial"));

	}


}
